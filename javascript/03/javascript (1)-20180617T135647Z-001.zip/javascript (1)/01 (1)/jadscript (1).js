

var txt00 = "hello \" world";
var number = 5.5;

var res00 = 0;
res00 = 9%2;

//alert(typeof txt00);
//alert(res00);

/*typeof definit l existance ou le type d une ver*/

/*prompt recupere string entree par user */

/*parseInt convertit une string en entier */

/*confirm boite yes annuler */






//txt00 = prompt('enter a number');
//number = parseInt(txt00);


/*var number00 = 5;
var number01 = 5;
var test = false;

test = number00 === number01;

alert(test);*/

/*
number = parseInt(prompt('entrer votre age'));

if(!number)
{
    alert('not number');
}

if(number<1 || number>120)
{
    alert('mauvaise plage d age');
}
else 
{
    if(number <= 17)
    {
	alert('not majeur');
    }

    if(number>17 && number <=49)
    {
	alert('major');
    }

    if(number>49 && number <=59)
    {
	alert('senior');
    }

     if(number>59 && number <=120)
    {
	alert('retired');
    }


    
}


*/



function sayHy()
{
var ohai='hello world';

}

var loop = true;
var forname = '';

alert('hello');

do
{

    forname = promp(entrez prénom);
    
}while(loop)

